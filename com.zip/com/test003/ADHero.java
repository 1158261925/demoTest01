package com.test003;

public class ADHero implements Mortal {

	@Override
	public void die() {
		// TODO Auto-generated method stub
		System.out.println("ADӢ�۱������ˣ�");
	}

}
