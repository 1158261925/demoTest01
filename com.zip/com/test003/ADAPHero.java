package com.test003;

public class ADAPHero implements Mortal{

	@Override
	public void die() {
		// TODO Auto-generated method stub
		System.out.println("ADAPӢ�۱������ˣ�");
	}

}
