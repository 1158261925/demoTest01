package com.test003;

public interface Mortal {
	public abstract void die();
}
