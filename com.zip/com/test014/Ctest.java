package com.test014;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Ctest {
	public static void main(String[] args) {
		File file=new File("D:/TestFiles/three/banana.txt");
		try {
			FileInputStream inputStream=new FileInputStream(file);
			byte[] arr=new byte[(int)file.length()];
			inputStream.read(arr);
			for(byte b:arr){
				System.out.println(b);
			}
			inputStream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
