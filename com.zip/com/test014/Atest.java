package com.test014;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Atest {
	public static void main(String[] args) {
		File file=new File("D:/TestFiles");
		System.out.println(file.getName());
		System.out.println(file.getAbsolutePath());
		System.out.println(file.isDirectory());
		System.out.println(file.isFile());
		System.out.println(file);
		System.out.println(file.length());
		System.out.println(file.lastModified());
		long time=file.lastModified();
		Date date=new Date(time);
		SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss SS");
		System.out.println(format.format(date));
		
	}
}
