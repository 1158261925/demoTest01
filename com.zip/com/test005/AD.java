package com.test005;

public interface AD {
	public abstract void physicAttack();
}
