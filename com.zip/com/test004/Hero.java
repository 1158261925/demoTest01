package com.test004;

public class Hero {
	public static void battleWin(){
		System.out.println("Hero battle win!");
	}
}
