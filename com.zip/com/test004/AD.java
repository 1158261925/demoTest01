package com.test004;

public interface AD {
	public abstract void physicAttack();
}
