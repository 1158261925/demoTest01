package com.test011;

public class Zest {
	public static void main(String[] args) {
		char a='��';
		Character aa=a;
		System.out.println(aa);
		
		System.out.println(Character.isDigit(a));
	}
}
