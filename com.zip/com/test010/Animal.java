package com.test010;

public abstract class Animal {
	protected int legs;
	protected Animal(int legs){
		this.legs=legs;
	}
	public abstract void eat();
	public void walk(){
		System.out.println(this.legs+"ֻ����·");
	}
	public static void main(String[] args) {
		//����֩��
		Animal spider=new Spider();
		spider.eat();
		System.out.println("֩����"+spider.legs+"���ȣ�");
		//����è
		Cat cat=new Cat();
		cat.eat();
		cat.play();
		//cat.setName("è��");
		System.out.println(cat.getName());
		System.out.println(cat.legs);
	}
}
class Spider extends Animal{
	public static final int legs=8;
	protected Spider() {
		super(legs);
	}

	@Override
	public void eat() {
		System.out.println("֩������ƳԶ�����");
		
	}
	
}
interface Pet{
	void setName(String name);
	String getName();
	void play();
}
class Cat extends Animal implements Pet{
	String name;
	static final int legs=4;
	protected Cat(String name) {
		super(legs);
		this.name=name;
	}
	protected Cat(){
		this("");
	}
	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("è�����ƳԶ�����");
	}
	@Override
	public void setName(String name) {
		// TODO Auto-generated method stub
		this.name=name;
	}
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return this.name;
	}
	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("èϲ���棡");
	}
	
}
class Fish extends Animal implements Pet{
	static final int legs=0;
	private String name;
	protected Fish() {
		super(legs);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void setName(String name) {
		// TODO Auto-generated method stub
		this.name=name;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return this.name;
	}

	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("��ϲ���棡");
	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("������Ƴ��㣡");
	}
	@Override
	public void walk(){
		System.out.println("�㲻������û���ȣ�");
	}
	
}




