package com.test010;

abstract class Animal {
	protected int legs;
	protected Animal(int legs){
		this.legs=legs;
	}
	public abstract void eat();
	public void walk(){
		System.out.println(this.legs+"ֻ����·");
	}
}
class Spider extends Animal{
	public static final int legs=8;
	protected Spider() {
		super(legs);
	}

	@Override
	public void eat() {
		System.out.println("֩������ƳԶ�����");
		
	}
	
}
interface Pet{
	void setName(String name);
	String getName();
	void play();
}
class Cat extends Animal{
	String name;
	static final int legs=4;
	protected Cat(String name) {
		super(legs);
		this.name=name;
	}
	protected Cat(){
		this("");
	}
	@Override
	public void eat() {
		// TODO Auto-generated method stub
		
	}
	
}





