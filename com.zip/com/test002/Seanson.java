package com.test002;

public enum Seanson {
	SPRING,SUMMER,AUTUMN,WINTER
}
